#include<iostream>
using namespace std;

int getBit(int n,int position){
	return ((n&(1<<position))!=0);
}

int setBit(int n,int position){
	return ((n | (1<<position)));
}

int clearBit(int n,int position){
	int first_complement=~(1<<position);
	return (n & first_complement);
}

int updateBit(int n,int position,int value){
	int clear=clearBit(n,position);
	return (clear | (value<<position));
}

int clear_Last_i_Bits(int n,int position){
	for(int i=0;i<position;i++){
		n=clearBit(n,i);
	}
	return n;
}

int clear_till_Range(int n,int start , int end){

	for(int i=start-1;i<end;i++){
		n=clearBit(n,i);
	}
	return n;
}

int replace_Bits(int n,int given,int start,int end){
	for(int i=start-1; i<end ; i++){
		n=clearBit(n,i);
	}
	cout<<n<<endl;
	given=(given<<start-1);
	 n=(n | given);
	 return n;
}

int main(){
	
	cout<<updateBit(5,1,1);
}
