#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
	pair<int,int> arr[][10]={ (2,3), (1,2), (3,4), (2,4), (1,4) };

	
}
