#include <iostream>
using namespace std;
int main(){
	string s="aeiefwfaesdcwe";
	string s2;
	for(int i=0;i<s.length();i++){
		if(s[i]=='a' or s[i]=='e' or s[i]=='i' or s[i]=='o' or s[i]=='u' )
		s2.push_back(s[i]);
	}
	cout<<s2;
}
