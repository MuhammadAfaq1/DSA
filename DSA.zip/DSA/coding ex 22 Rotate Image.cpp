#include <iostream>
#include <vector>
using namespace std;
int main(){

	vector<vector<int>> matrix = {{1,2,3},{4,5,6},{7,8,9}};
	
	cout
	int a=0;
	int b=matrix.size()-1;
	
	while(a<b){
		for(int i=0;i<b-a;i++){
		
				swap(matrix[a][a+i], matrix[a+i][b]);
                swap(matrix[a][a+i], matrix[b][b-i]);
                swap(matrix[a][a+i], matrix[b-i][a]);
		}
		a++;
		b--;
	}
}
