#include<iostream>
using namespace std;

unsigned long convert_to_binary(int n){
	unsigned long num;
	int last_bit,i=1;
	while(n>0){
		last_bit=n%2;
		num=num+last_bit*i;
		n=n/2;
		i*=10;
	}
	return num;
}
int earth_level(unsigned long number){
	unsigned long binary,sum=0;
	binary=convert_to_binary(number);
	
	while(binary!=0){
	unsigned long t=binary%2;	
	sum+=t;
	binary/=10;
			
		}
		return sum;
	}


int main(){
	cout<<earth_level(10);
}
