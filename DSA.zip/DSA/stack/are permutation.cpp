//
//  are permutation.cpp
//  stack
//
//  Created by Mac on 02/12/2022.
//

#include <iostream>
using namespace std;
int main(){
    cout<<":sdvcds";
    
}
