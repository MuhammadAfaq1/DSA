
#include<iostream>
using namespace std;

class Stacks{
private:
    struct node{
        int data;
        node* down;
    };
    node* top;
public:
    Stacks(){
        top=NULL;
    }
    void push(int value){
        node* n=new node;
        n->data=value;
        n->down=top;
        top=n;
    }
    void pop(){
        node* temp;
        temp=top;
        node* popped;
        if(top==NULL){
            cout<<"STACK OVERFLOW"<<endl;
        }
        else{
            cout<<top->data<<" POPPED"<<endl;
            top=top->down;
            popped=temp;
            delete temp;
        }
    }
    
    void Display(){
        node* temp=top;
        cout<<"STACK: ";
        if(top==NULL)
            cout<<"EMPTY"<<endl;
        while(temp!=NULL){
            cout<<temp->data<<" ";
            temp=temp->down;
        }
        cout<<endl;
    }};

int main(){
    Stacks s;
    s.push(1);
}
