#include<iostream>
using namespace std;
struct node{
    int data;
   struct node * left;
   struct node* right;

    node(int val){
        data=val;
        left=NULL;
        right=NULL;
    }
};


void preOrder(struct node* root){
    if(root == NULL)
    return;
    cout<<root->data<<" ";
    preOrder(root->left);
    preOrder(root->right);

}

void inOrder(struct node* root){
    if (root == NULL)
    return;

    inOrder(root->left);
    cout<<root->data<<" ";
    inOrder(root->right);
}

void postOrder(struct node* root){
    if(root == NULL)
    return ;
    postOrder(root->left);
    postOrder(root->right);
    cout<<root->data<<" ";
}

node* searchInBST(node* root, int key){

    if(root == NULL)
    return NULL;

   if(root->data == key)
    return root;

    return searchInBST(root -> left , key);
    return  searchInBST(root -> right , key);
}

node* InOrdSucc(node* root){
    node* curr=root;
    while(curr && curr->left !=NULL)
    curr=curr->left;
    return curr;;
}
node* deleteInBST(node* root, int key){
    if(key < root->data)
    root->left=deleteInBST(root->left,key);
    else if(key > root->data)
    root->right=deleteInBST(root->right,key);
    else 
{
    if(root->left == NULL){
        node* temp=root->right;
        free(root);
        return temp;
    }
    else if (root->right == NULL ){
        node * temp=root->left;
        free (root);
        return temp;
    }
    node* temp=InOrdSucc(root->right);
    root->data=temp->data;
    root->right=deleteInBST(root->right , temp ->data);
}
    return root;
}

int main(){
    node* root=new node(1);

    root->left=new node(2);
    root->right=new node(3);

    root->left->left=new node(4);
    root->left->right=new node(5);

    root->right->left=new node(6);
    root->right->right=new node(7);
    
     //preOrder(root);
     inOrder(root);
    // postOrder(root);
root=deleteInBST(root,5);
inOrder(root);  

//    if(searchInBST(root, 2) == NULL)
//    cout<<"key doesn't exit in BST";
//    else 
//    cout<<"key exists";
}